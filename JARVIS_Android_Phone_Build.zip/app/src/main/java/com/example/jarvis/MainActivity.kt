package com.example.jarvis

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private lateinit var statusText: TextView
    private lateinit var responseText: TextView
    private lateinit var commandInput: EditText
    private lateinit var listenButton: Button
    private var ttsReady = false
    private var listening = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(7, 17, 31)
        window.navigationBarColor = android.graphics.Color.rgb(7, 17, 31)
        tts = TextToSpeech(this, this)
        buildUi()
        requestAudioPermission()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(20), dp(20), dp(20))
            setBackgroundColor(android.graphics.Color.rgb(7, 17, 31))
        }

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }

        val title = TextView(this).apply {
            text = "J.A.R.V.I.S"
            textSize = 32f
            letterSpacing = 0.18f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.rgb(0, 217, 255))
            setPadding(0, dp(8), 0, dp(4))
        }
        content.addView(title, matchWrap())

        val subtitle = TextView(this).apply {
            text = "PERSONAL VOICE ASSISTANT"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(0xFFB8D4E8.toInt())
            setPadding(0, 0, 0, dp(18))
        }
        content.addView(subtitle, matchWrap())

        statusText = TextView(this).apply {
            text = "SYSTEM READY"
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(0xFF00D9FF.toInt())
            setPadding(0, dp(8), 0, dp(14))
        }
        content.addView(statusText, matchWrap())

        listenButton = makeButton("🎙  START LISTENING") { startListening() }
        content.addView(listenButton, matchWrap())

        val stopButton = makeButton("STOP LISTENING") { stopListening() }
        content.addView(stopButton, matchWrap())

        commandInput = EditText(this).apply {
            hint = "Type a command..."
            textSize = 16f
            setSingleLine(true)
            setTextColor(android.graphics.Color.WHITE)
            setHintTextColor(0xFF91A8BB.toInt())
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(0xFF14283C.toInt())
        }
        val inputParams = matchWrap()
        inputParams.topMargin = dp(16)
        content.addView(commandInput, inputParams)

        content.addView(makeButton("RUN COMMAND") {
            handleCommand(commandInput.text.toString())
        }, matchWrap())

        val responseHeading = TextView(this).apply {
            text = "JARVIS RESPONSE"
            textSize = 14f
            setTextColor(0xFF00D9FF.toInt())
            setPadding(0, dp(20), 0, dp(8))
        }
        content.addView(responseHeading, matchWrap())

        responseText = TextView(this).apply {
            text = "Hello! I am JARVIS. Tap Start Listening or type a command."
            textSize = 17f
            setTextColor(android.graphics.Color.WHITE)
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(0xFF14283C.toInt())
        }
        content.addView(responseText, matchWrap())

        val examples = TextView(this).apply {
            text = "Try: time • date • open YouTube • open Maps • open WhatsApp • search Python • calculate 25*4 • help"
            textSize = 13f
            setTextColor(0xFF9CB5C9.toInt())
            setPadding(0, dp(16), 0, dp(8))
        }
        content.addView(examples, matchWrap())

        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        setContentView(root)
    }

    private fun makeButton(label: String, action: () -> Unit): Button {
        return Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 15f
            setTextColor(0xFF07111F.toInt())
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF00D9FF.toInt()))
            setOnClickListener { action() }
            val p = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
            p.topMargin = dp(8)
            layoutParams = p
        }
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun requestAudioPermission() {
        if (Build.VERSION.SDK_INT >= 23 &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 100)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100) {
            statusText.text = if (grantResults.isNotEmpty() &&
                grantResults[0] == PackageManager.PERMISSION_GRANTED) "MICROPHONE PERMISSION GRANTED"
            else "MICROPHONE PERMISSION DENIED"
        }
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) {
            tts?.language = Locale("en", "IN")
        }
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestAudioPermission()
            speak("Please allow microphone permission first.")
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak("Speech recognition is not available on this phone. You can type commands instead.")
            return
        }
        stopListening()
        try {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
            speechRecognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    statusText.text = "LISTENING — SPEAK NOW"
                }
                override fun onBeginningOfSpeech() { statusText.text = "HEARING YOUR VOICE..." }
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { statusText.text = "PROCESSING..." }
                override fun onError(error: Int) {
                    listening = false
                    statusText.text = "LISTENING STOPPED — TAP TO RETRY"
                }
                override fun onResults(results: Bundle?) {
                    listening = false
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull().orEmpty()
                    commandInput.setText(text)
                    handleCommand(text)
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-IN")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to JARVIS")
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }
            listening = true
            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            statusText.text = "COULD NOT START MICROPHONE"
            speak("I could not start listening. Check microphone permission and try again.")
        }
    }

    private fun stopListening() {
        listening = false
        try { speechRecognizer?.stopListening() } catch (_: Exception) {}
        try { speechRecognizer?.cancel() } catch (_: Exception) {}
        speechRecognizer?.destroy()
        speechRecognizer = null
        if (::statusText.isInitialized) statusText.text = "SYSTEM READY"
    }

    private fun speak(message: String) {
        responseText.text = message
        statusText.text = "JARVIS RESPONSE"
        if (ttsReady) tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    private fun openWeb(url: String, message: String) {
        speak(message)
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: ActivityNotFoundException) {
            speak("No browser app was found to open that page.")
        }
    }

    private fun launchPackage(packageName: String, appName: String) {
        val intent = packageManager.getLaunchIntentForPackage(packageName)
        if (intent != null) {
            speak("Opening $appName.")
            try { startActivity(intent) } catch (_: Exception) { speak("I could not open $appName.") }
        } else {
            speak("$appName is not installed. I will open its website instead.")
            val url = when (packageName) {
                "com.google.android.youtube" -> "https://www.youtube.com/"
                "com.google.android.apps.maps" -> "https://maps.google.com/"
                "com.whatsapp" -> "https://www.whatsapp.com/"
                "com.google.android.gm" -> "https://mail.google.com/"
                "com.android.chrome" -> "https://www.google.com/"
                else -> "https://www.google.com/"
            }
            openWeb(url, "Opening $appName.")
        }
    }

    private fun handleCommand(command: String) {
        val c = command.trim().lowercase(Locale.ROOT)
        if (c.isBlank()) {
            speak("Please say or type a command.")
            return
        }

        when {
            c.contains("time") -> speak("The time is " +
                SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date()))
            c.contains("date") || c == "today" || c.contains("what day") ->
                speak("Today is " + SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date()))
            c.contains("your name") || c.contains("who are you") ->
                speak("I am JARVIS, your personal Android voice assistant.")
            c == "hello" || c == "hi" || c.contains("hello jarvis") || c.contains("hey jarvis") ->
                speak("Hello! JARVIS is online. How can I help?")
            c.contains("how are you") -> speak("All systems are running smoothly.")
            c.contains("joke") -> speak("Why do programmers prefer dark mode? Because light attracts bugs!")
            c.contains("open youtube") -> launchPackage("com.google.android.youtube", "YouTube")
            c.contains("open maps") || c.contains("open google maps") ->
                launchPackage("com.google.android.apps.maps", "Google Maps")
            c.contains("open whatsapp") -> launchPackage("com.whatsapp", "WhatsApp")
            c.contains("open gmail") -> launchPackage("com.google.android.gm", "Gmail")
            c.contains("open chrome") || c.contains("open browser") ->
                launchPackage("com.android.chrome", "Chrome")
            c.contains("open camera") -> {
                speak("Opening Camera.")
                try { startActivity(Intent("android.media.action.IMAGE_CAPTURE")) }
                catch (_: Exception) { speak("I could not open the camera.") }
            }
            c.contains("open settings") -> {
                speak("Opening Android Settings.")
                startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
            }
            c.contains("open phone") || c.contains("open dialer") -> {
                speak("Opening the phone dialer.")
                startActivity(Intent(Intent.ACTION_DIAL))
            }
            c.startsWith("search ") -> {
                val q = command.trim().substringAfter(" ", "")
                openWeb("https://www.google.com/search?q=" + Uri.encode(q), "Searching Google for $q.")
            }
            c.startsWith("calculate ") -> calculate(command.trim().substringAfter("calculate ", ""))
            c.contains("help") || c.contains("what can you do") ->
                speak("I can tell the time and date, open YouTube, Maps, WhatsApp, Gmail, Chrome, Camera, Settings and Phone, search Google, calculate simple expressions, and tell jokes.")
            c.contains("thank") -> speak("You're welcome. JARVIS is ready whenever you need me.")
            else -> speak("I do not know that command yet. Say help, or say search followed by your topic.")
        }
    }

    private fun calculate(expression: String) {
        // Deliberately supports only two numbers and one operator for safety.
        val match = Regex("""^\s*(-?\d+(?:\.\d+)?)\s*([+\-*/x])\s*(-?\d+(?:\.\d+)?)\s*$""")
            .find(expression)
        if (match == null) {
            speak("Try a simple calculation such as calculate 25 times 4, or calculate 12 plus 8.")
            return
        }
        val a = match.groupValues[1].toDouble()
        val op = match.groupValues[2]
        val b = match.groupValues[3].toDouble()
        val result = when (op) {
            "+" -> a + b
            "-" -> a - b
            "*", "x" -> a * b
            "/" -> if (b != 0.0) a / b else Double.NaN
            else -> Double.NaN
        }
        speak(if (result.isFinite()) "The answer is $result" else "That calculation is not valid.")
    }

    override fun onDestroy() {
        stopListening()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
