# JARVIS Android Assistant — phone-only build

This is a native Android Kotlin starter project. You can prepare it and build the APK using only your Android phone by uploading the project to a GitHub repository and using GitHub Actions (cloud build). You do not need Android Studio on the phone.

## Included features
- Native Android app UI
- Speech recognition via Android's installed speech recognition service
- Spoken responses using Android Text-to-Speech
- Commands: time, date, hello, joke, help
- Opens YouTube, Google Maps, WhatsApp, Gmail, Chrome, Camera, Android Settings and Phone dialer when available
- Google web search
- Basic safe calculator for two numbers and one operator

## Build using only your Android phone

1. Download and extract `JARVIS_Android_Phone_Build.zip` on your phone if your file manager supports ZIP extraction.
2. Open https://github.com/ in Chrome and sign in or create an account.
3. Create a new **public** repository named `jarvis-android` (public is simplest for GitHub Actions on a free account; private repositories may also work within account limits).
4. In the repository, use **Add file → Upload files**. Upload the contents of this project, not the outer ZIP. Keep `.github/workflows/build-apk.yml` in its exact folder path. If GitHub's mobile site makes nested-folder uploads difficult, switch Chrome to **Desktop site**.
5. Commit the files to the `main` branch.
6. Open the repository's **Actions** tab and choose **Build JARVIS APK**. Tap **Run workflow** if it has not started automatically.
7. Wait until the workflow finishes with a green check mark.
8. Open that workflow run, scroll to **Artifacts**, and download `JARVIS-debug-APK`.
9. Extract the downloaded artifact ZIP. Inside it is `app-debug.apk`.
10. Tap the APK to install. If Android blocks it, allow **Install unknown apps** for the browser or file manager you used, then retry. Only install APKs you built or trust.
11. Open **JARVIS Assistant**, grant microphone permission, connect Bluetooth earbuds before listening, and test with “Hello JARVIS”.

## Bluetooth notes
Android's speech recognition service normally uses the active system audio input, but the exact Bluetooth microphone routing depends on the phone, Android version, headset, and recognition provider. Connect the earbuds before pressing Start Listening. Android Text-to-Speech usually follows the system's active audio output.

## Limitations
- This starter does not have a cloud generative-AI brain. Its commands are rule-based.
- Speech recognition may require internet and a speech service installed/enabled on Android.
- It does not continuously listen in the background or use a wake word.
- Phone actions are limited to explicit intents and installed apps; Android security restrictions still apply.
- The project creates a **debug APK** for testing, not a Play Store release.
